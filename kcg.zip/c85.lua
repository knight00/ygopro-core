local s,id=GetID()
if s then
	function s.initial_effect(c)
	end
end
if not id then id=85 end
if not DestinyDraw then
	DestinyDraw={}
	aux.GlobalCheck(DestinyDraw,function()
		DestinyDraw[0]=nil
		DestinyDraw[1]=nil
	end)
	local function finishsetup()
		local e1=Effect.GlobalEffect()
		e1:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
		e1:SetCode(EVENT_STARTUP)
		e1:SetOperation(DestinyDraw.op)
		Duel.RegisterEffect(e1,0)

		local e2=Effect.GlobalEffect()
		e2:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE)
		e2:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
		e2:SetCode(EVENT_PREDRAW)
		e2:SetCondition(DestinyDraw.drcon)
		e2:SetOperation(DestinyDraw.drop)
		Duel.RegisterEffect(e2,0)
		local e3=e2:Clone()
		Duel.RegisterEffect(e3,1)
	end

	function DestinyDraw.op(e,tp,eg,ep,ev,re,r,rp)
		local e1=Effect.GlobalEffect()
		e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_IGNORE_IMMUNE+EFFECT_FLAG_DELAY)
		e1:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
		e1:SetCode(EVENT_SPSUMMON_SUCCESS)
		e1:SetTargetRange(LOCATION_MZONE,LOCATION_MZONE)
		e1:SetCondition(DestinyDraw.xyzsumcon)
		e1:SetOperation(DestinyDraw.xyzsumop)
		Duel.RegisterEffect(e1,tp)

		-- local g=Duel.GetMatchingGroup(function(sc) return sc:GetCode()~=sc:GetOriginalCode() and sc.xyz_number~=nil and not Duel.IsExistingMatchingCard(function(sc2) return sc2:GetCode()==sc2:GetOriginalCode() and sc2:GetCode()==sc:GetCode() end,0,0xff,0xff,1,sc) end,0,0xff,0xff,nil)
		-- for tc in aux.Next(g) do 
		-- 	Duel.CreateToken(ttp,tc:GetCode())
		-- end		

		for ttp=0,1 do
			local b1=(Duel.GetMatchingGroupCount(DestinyDraw.DDfiler,ttp,LOCATION_EXTRA,0,nil)>0)
			local b2=(Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_EXTRA,0,nil,0x7f)>0)
			local b3=(Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND,0,nil,24094653)>0
			and Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_DECK+LOCATION_HAND,0,nil,0x3008)>0)
			local b4=(Duel.GetMatchingGroupCount(DestinyDraw.RDSfiler,ttp,LOCATION_EXTRA,0,nil)>0
			or (Duel.GetMatchingGroupCount(DestinyDraw.RRDSfiler,ttp,LOCATION_EXTRA,0,nil)>0
			and Duel.GetMatchingGroupCount(DestinyDraw.RRDSfiler2,ttp,LOCATION_DECK+LOCATION_HAND,0,nil,1)>0))
			local b5=(Duel.GetMatchingGroupCount(DestinyDraw.DTMfiler,ttp,LOCATION_DECK+LOCATION_HAND,0,nil,tp)>0)
			local b6=((Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND,0,nil,10000020)>0
			  and Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND,0,nil,10000000)>0
			  and Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND,0,nil,10000010)>0)
			  or (Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND,0,nil,281)>0
			  and Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND,0,nil,280)>0
			  and Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND,0,nil,282)>0))
			local b7=(Duel.GetMatchingGroupCount(Card.IsType,ttp,LOCATION_DECK,0,nil,TYPE_FIELD)>0)
			local b8=(Duel.GetMatchingGroupCount(Card.IsType,ttp,LOCATION_EXTRA,0,nil,TYPE_MONSTER)==0
			and Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_DECK+LOCATION_HAND,0,nil,0x909)>9)	
			local b9=(Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_DECK+LOCATION_HAND,0,nil,0x5)>9)
			local b10=((Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_DECK+LOCATION_HAND,0,nil,0x9f)>1) or (Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_DECK+LOCATION_HAND,0,nil,0xf8)>1))
			local b11=(Duel.GetMatchingGroupCount(Card.IsType,ttp,LOCATION_EXTRA,0,nil,TYPE_LINK)>9)
			local b12=((Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND,0,nil,69890967)>0) and (Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND,0,nil,32491822)>0) and (Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND,0,nil,6007213)>0))
			local sel=0
			local off=1
			local ops={}
			local opval={}
			ops[off]=aux.Stringid(826,13)
			opval[off-1]=1
			off=off+1
			if b1 or b2 or b3 or b4 or b5 or b6 or b7 or b8 or b9 or b10 or b11 or b12 then
				ops[off]=aux.Stringid(826,12)
				opval[off-1]=2
				off=off+1
			end 
			local op=Duel.SelectOption(ttp,table.unpack(ops))
			if opval[op]==1 then
				local g=Duel.GetFieldGroup(ttp,LOCATION_DECK+LOCATION_HAND,0)
				Duel.Hint(HINT_SELECTMSG,ttp,aux.Stringid(826,11))
				DestinyDraw[ttp]=aux.SelectUnselectGroup(g,e,ttp,1,5,aux.dncheck,1,ttp)
				DestinyDraw[ttp]:KeepAlive()
				Duel.RegisterFlagEffect(ttp,99999980,0,0,1)
				local dr=Duel.CreateToken(ttp,512)   
				dr:SetCardData(CARDDATA_TYPE,TYPE_SPELL)
				Duel.Remove(dr,POS_FACEUP,REASON_RULE)
				--immune
				local e121=Effect.CreateEffect(dr)
				e121:SetType(EFFECT_TYPE_SINGLE)
				e121:SetProperty(EFFECT_FLAG_SINGLE_RANGE+EFFECT_FLAG_CANNOT_DISABLE)
				e121:SetRange(LOCATION_REMOVED)
				e121:SetCode(EFFECT_IMMUNE_EFFECT)
				e121:SetValue(1)
				dr:RegisterEffect(e121)
				local e122=Effect.CreateEffect(dr)
				e122:SetType(EFFECT_TYPE_SINGLE)
				e122:SetCode(EFFECT_CANNOT_BE_EFFECT_TARGET)
				e122:SetProperty(EFFECT_FLAG_SINGLE_RANGE+EFFECT_FLAG_CANNOT_DISABLE)
				e122:SetRange(LOCATION_REMOVED)
				e122:SetValue(1)
				dr:RegisterEffect(e122)
			end
			local tt				
			if opval[op]==2 then
				tt=Duel.CreateToken(ttp,157)
				tt:SetCardData(CARDDATA_TYPE,TYPE_SPELL)
				Duel.Remove(tt,POS_FACEUP,REASON_RULE)
				local sel=0
				local off=1
				local ops={}
				local opval={}
				if b1 then
					ops[off]=aux.Stringid(123106,8)
					opval[off-1]=1
					off=off+1
				end
				if b2 then
					ops[off]=aux.Stringid(111011901,2)
					opval[off-1]=2
					off=off+1
				end
				if b3 then
					ops[off]=aux.Stringid(123106,11)
					opval[off-1]=3
					off=off+1
				end
				if b4 then
					ops[off]=aux.Stringid(13709,15)
					opval[off-1]=4
					off=off+1
				end
				if b5 then
					ops[off]=aux.Stringid(826,7)
					opval[off-1]=5
					off=off+1
				end
				if b6 then
					ops[off]=aux.Stringid(826,6)
					opval[off-1]=6
					off=off+1
				end
				if b7 then
					ops[off]=aux.Stringid(48934760,0)
					opval[off-1]=7
					off=off+1
				end
				if b8 then
					ops[off]=aux.Stringid(13713,8)
					opval[off-1]=8
					off=off+1
				end
				if b9 then
					ops[off]=aux.Stringid(23846921,0)
					opval[off-1]=9
					off=off+1
				end
				if b10 then
					ops[off]=aux.Stringid(13712,0)
					opval[off-1]=10
					off=off+1
				end
				if b11 then
					ops[off]=aux.Stringid(826,5)
					opval[off-1]=11
					off=off+1
				end
				if b12 then
					ops[off]=aux.Stringid(826,6)
					opval[off-1]=12
					off=off+1
				end
				local op=Duel.SelectOption(ttp,table.unpack(ops))   
				if opval[op]==1 then 
					Duel.RegisterFlagEffect(ttp,90999980,0,0,1) 
					tt:SetEntityCode(513,true) 
					Duel.CreateToken(ttp,98)   
				end
				if opval[op]==2 then 
					Duel.RegisterFlagEffect(ttp,91999980,0,0,1)
					tt:SetEntityCode(514,true) 
				end
				if opval[op]==3 then 
					Duel.RegisterFlagEffect(ttp,92999980,0,0,1)
					tt:SetEntityCode(515,true) 
				end
				if opval[op]==4 then 
					Duel.RegisterFlagEffect(ttp,93999980,0,0,1)
					tt:SetEntityCode(517,true) 
				end
				if opval[op]==5 then 
					Duel.RegisterFlagEffect(ttp,90899980,0,0,1)
					tt:SetEntityCode(518,true)
				end
				if opval[op]==6 then 
					Duel.RegisterFlagEffect(ttp,90799980,0,0,1)
					tt:SetEntityCode(519,true) 
				end
				if opval[op]==7 then 
					Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
					local field=Duel.SelectMatchingCard(ttp,Card.IsType,ttp,LOCATION_DECK,0,1,1,nil,TYPE_FIELD):GetFirst()	
					Duel.MoveSequence(field,0) 
				end
				if opval[op]==8 then 
					Duel.RegisterFlagEffect(ttp,388,0,0,1)
					local tokeng=Group.CreateGroup()
					tt:SetEntityCode(520,true)
					for i=1,100 do
						if aux.list[i] then 
							local notoken=Duel.CreateToken(ttp,aux.list[i])
							if not notoken:IsCode(13714) then 
								notoken:ReplaceEffect(241,RESET_EVENT+RESETS_REDIRECT)
								local e92=Effect.CreateEffect(notoken)
								e92:SetProperty(EFFECT_FLAG_SET_AVAILABLE+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_CANNOT_DISABLE+EFFECT_FLAG_DAMAGE_CAL+EFFECT_FLAG_DAMAGE_STEP)
								e92:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_CONTINUOUS)
								e92:SetCode(EVENT_SPSUMMON_SUCCESS)
								e92:SetOperation(function(...) notoken:ReplaceEffect(notoken:GetOriginalCode(),0) end)
								notoken:RegisterEffect(e92,true)
							end
							notoken:RegisterFlagEffect(85,0,0,0)
							tokeng:AddCard(notoken)
							local e90=Effect.CreateEffect(notoken)
							e90:SetDescription(1165)
							e90:SetProperty(EFFECT_FLAG_SET_AVAILABLE+EFFECT_FLAG_UNCOPYABLE)
							e90:SetType(EFFECT_TYPE_IGNITION)
							e90:SetRange(LOCATION_EXTRA)
							e90:SetCondition(DestinyDraw.xyzscon)
							e90:SetTarget(DestinyDraw.distg) 
							e90:SetOperation(DestinyDraw.xyzsactivate)
							notoken:RegisterEffect(e90,true)
							if notoken.alterxyz_filter~=nil then
								local e91=Effect.CreateEffect(notoken)
								e91:SetDescription(notoken.desc)
								e91:SetProperty(EFFECT_FLAG_SET_AVAILABLE+EFFECT_FLAG_UNCOPYABLE)
								e91:SetType(EFFECT_TYPE_IGNITION)
								e91:SetRange(LOCATION_EXTRA)
								e91:SetCondition(DestinyDraw.xxyzcon1)
								e91:SetTarget(DestinyDraw.distg)
								e91:SetOperation(DestinyDraw.xyzsactivate2)
								notoken:RegisterEffect(e91,true) 
							end
						end 
					end 
					Duel.SendtoDeck(tokeng,ttp,0,REASON_RULE)
				end

				if opval[op]==9 then
					local e3=Effect.GlobalEffect()
					e3:SetType(EFFECT_TYPE_FIELD)
					e3:SetCode(73206827)
					e3:SetTargetRange(LOCATION_ONFIELD,LOCATION_ONFIELD)
					e3:SetTarget(aux.TargetBoolFunction(Card.IsSetCard,0x5))
					e3:SetCondition(aux.effectcon)
					Duel.RegisterEffect(e3,ttp) 
				end

				if opval[op]==10 then 
					Duel.RegisterFlagEffect(ttp,703,0,0,1) 
					tt:SetEntityCode(521,true)
					local token1=nil local token2=nil local token3=nil local token4=nil local token5=nil local token6=nil local token7=nil local token8=nil local token9=nil local token10=nil local token11=nil local token12=nil local token13=nil local token14=nil local token15=nil local token16=nil local token17=nil local token18=nil local token19=nil
					if Duel.GetMatchingGroupCount(Card.IsCode,ttp,0xff,0,nil,37)<1 then token1=Duel.CreateToken(ttp,37) end
					if Duel.GetMatchingGroupCount(Card.IsCode,ttp,0xff,0,nil,38)<1 then token2=Duel.CreateToken(ttp,38) end
					if Duel.GetMatchingGroupCount(Card.IsCode,ttp,0xff,0,nil,693)<1 then token3=Duel.CreateToken(ttp,693) end
					if Duel.GetMatchingGroupCount(Card.IsCode,ttp,0xff,0,nil,59123194)<1 then token12=Duel.CreateToken(ttp,511002709) end
					if Duel.GetMatchingGroupCount(Card.IsCode,ttp,0xff,0,nil,80896940)<1 then token13=Duel.CreateToken(ttp,692) end
					if Duel.GetMatchingGroupCount(Card.IsCode,ttp,0xff,0,nil,50954680)<1 then token14=Duel.CreateToken(ttp,84) end
					if Duel.GetMatchingGroupCount(Card.IsCode,ttp,0xff,0,nil,90036274)<1 then token15=Duel.CreateToken(ttp,511009095) end
					if Duel.GetMatchingGroupCount(Card.IsCode,ttp,0xff,0,nil,51570882)<1 then token16=Duel.CreateToken(ttp,511009381) end
					if Duel.GetMatchingGroupCount(Card.IsCode,ttp,0xff,0,nil,511009415)<1 then token17=Duel.CreateToken(ttp,511009415) end
					if Duel.GetMatchingGroupCount(Card.IsCode,ttp,0xff,0,nil,1621413)<1 then token18=Duel.CreateToken(ttp,511009074) end
					if Duel.GetMatchingGroupCount(Card.IsCode,ttp,0xff,0,nil,511009387)<1 then token19=Duel.CreateToken(ttp,511009387) end
					if Duel.GetMatchingGroupCount(Card.IsCode,ttp,0xff,0,nil,16691074)<1 then token4=Duel.CreateToken(ttp,16691074) end
					if Duel.GetMatchingGroupCount(Card.IsCode,ttp,0xff,0,nil,86238081)<1 then token5=Duel.CreateToken(ttp,511009340) end
					if Duel.GetMatchingGroupCount(Card.IsCode,ttp,0xff,0,nil,45627618)<1 then token6=Duel.CreateToken(ttp,51370167) end
					if Duel.GetMatchingGroupCount(Card.IsCode,ttp,0xff,0,nil,58074177)<1 then token7=Duel.CreateToken(ttp,511009588) end
					if Duel.GetMatchingGroupCount(Card.IsCode,ttp,0xff,0,nil,80696379)<1 then token8=Duel.CreateToken(ttp,80696379) end
					if Duel.GetMatchingGroupCount(Card.IsCode,ttp,0xff,0,nil,53262004)<1 then token9=Duel.CreateToken(ttp,53262004) end
					if Duel.GetMatchingGroupCount(Card.IsCode,ttp,0xff,0,nil,65029288)<1 then token10=Duel.CreateToken(ttp,65029288) end
					if Duel.GetMatchingGroupCount(Card.IsCode,ttp,0xff,0,nil,45014450)<1 then token11=Duel.CreateToken(ttp,511009587) end
					local tokeng=Group.FromCards(token1,token2,token3,token4,token5,token6,token7,token8,token9,token10,token11,token12,token13,token14,token15,token16,token17,token18,token19)
					if tokeng:GetCount()>0 then
						Duel.Remove(tokeng,POS_FACEUP,REASON_RULE) 
						Duel.SendtoDeck(tokeng,ttp,0,REASON_RULE) 
						Duel.ChangePosition(tokeng,POS_FACEDOWN,POS_FACEDOWN,POS_FACEDOWN,POS_FACEDOWN)
					end
					if Duel.GetMatchingGroupCount(Card.IsType,ttp,LOCATION_DECK,0,nil,TYPE_PENDULUM)>1 and Duel.SelectYesNo(ttp,aux.Stringid(13712,0)) then 
						Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
						local destinytc=Duel.SelectMatchingCard(ttp,Card.IsType,ttp,LOCATION_DECK,0,1,2,nil,TYPE_PENDULUM)
						Duel.MoveSequence(destinytc:GetFirst(),0) 
						if destinytc:GetCount()>1 then
							Duel.MoveSequence(destinytc:GetNext(),0) 
						end
						Duel.Hint(HINT_MESSAGE,1-ttp,aux.Stringid(13712,0)) 
					end
				end   

				if opval[op]==11 then 
					Duel.RegisterFlagEffect(ttp,784,0,0,1,Duel.GetLP(ttp))
					tt:SetEntityCode(14,true) 
				end
				if opval[op]==12 then 
					Duel.RegisterFlagEffect(ttp,10000004,0,0,1)
					tt:SetEntityCode(25,true)	
				end
			end
		end
		e:Reset()
	end	

	function DestinyDraw.xyzsumcon(e,tp,eg,ep,ev,re,r,rp)
		return eg:IsExists(DestinyDraw.xyzsumfilter,1,nil)
	end
	function DestinyDraw.xyzsumfilter(c)
		return c:IsSetCard(0x48)
	end
	function DestinyDraw.xyzsumop(e,tp,eg,ep,ev,re,r,rp)
		if not eg:IsExists(DestinyDraw.xyzsumfilter,1,nil) then return end
		local g=eg:Filter(DestinyDraw.xyzsumfilter,nil)
		local tc=g:GetFirst()
		while tc do
			--cannot destroyed
			local e0=Effect.CreateEffect(tc)
			e0:SetType(EFFECT_TYPE_SINGLE)
			e0:SetCode(EFFECT_INDESTRUCTABLE_BATTLE)
			e0:SetValue(DestinyDraw.indes)
			tc:RegisterEffect(e0,true)
			tc=g:GetNext() 
		end
	end
	function DestinyDraw.indes(e,c)
		return not e:GetHandler():GetBattleTarget():IsSetCard(0x48) 
	end

	function DestinyDraw.distg(e,tp,eg,ep,ev,re,r,rp,chk)
		if chk==0 then return true end
		Duel.SetChainLimit(aux.FALSE)
	end
	--Over-hundred
	function DestinyDraw.chk2(c,code)
		return c:GetOriginalCode()==code
	end
	function DestinyDraw.DDfiler(c)
		return c:IsType(TYPE_XYZ) 
		and (Duel.GetMatchingGroupCount(DestinyDraw.chk2,c:GetControler(),LOCATION_DECK+LOCATION_HAND,0,nil,11370100)>0
		  or Duel.GetMatchingGroupCount(DestinyDraw.chk2,c:GetControler(),LOCATION_DECK+LOCATION_HAND,0,nil,13705015)>0
		  or Duel.GetMatchingGroupCount(DestinyDraw.chk2,c:GetControler(),LOCATION_DECK+LOCATION_HAND,0,nil,150000109)>0
		  or Duel.GetMatchingGroupCount(DestinyDraw.chk2,c:GetControler(),LOCATION_DECK+LOCATION_HAND,0,nil,453)>0
		  or Duel.GetMatchingGroupCount(DestinyDraw.chk2,c:GetControler(),LOCATION_DECK+LOCATION_HAND,0,nil,454)>0
		  or Duel.GetMatchingGroupCount(DestinyDraw.chk2,c:GetControler(),LOCATION_DECK+LOCATION_HAND,0,nil,66)>0)
	end
	function DestinyDraw.DDfiler2(c)
		local no=c.xyz_number
		return no and no>=101 and no<=107 and not c:IsSetCard(0x1048) and not c:IsSetCard(0x2048)
	end
	--Cartoon World
	function DestinyDraw.DTMfiler(c,tp)
		return Duel.GetMatchingGroupCount(DestinyDraw.DTMfiler2,tp,LOCATION_DECK+LOCATION_HAND,0,nil)>0
		and Duel.GetMatchingGroupCount(Card.IsCode,tp,LOCATION_DECK+LOCATION_HAND,0,nil,15259703)>0
	end
	function DestinyDraw.DTMfiler2(c)
		return c:IsSetCard(0x62) and c:IsType(TYPE_MONSTER) 
	end
	function DestinyDraw.DTMfiler3(c)
		return c:IsSetCard(0x62) and c:IsFaceup() 
	end
	function DestinyDraw.DTMfiler4(c)
		return c:IsCode(15259703) and c:IsFaceup() 
	end	
	--Gods
	function DestinyDraw.DGDfiler(c,ttp,code1,code2,code3,code4,code5,code6)
		local TID=Duel.GetTurnCount()
		return (c:GetCode()==code1 or c:GetCode()==code4) and c:GetTurnID()==TID and c:GetPosition()==POS_FACEUP_ATTACK
			and Duel.CheckReleaseGroup(ttp,DestinyDraw.DGDfiler3,1,nil,code2,code5,c:GetTurnID())
			and Duel.CheckReleaseGroup(ttp,DestinyDraw.DGDfiler3,1,nil,code3,code6,c:GetTurnID())
	end
	function DestinyDraw.DGDfiler3(c,code,code2,ID)
		return (c:GetCode()==code or c:GetCode()==code2) and c:GetTurnID()==ID and c:GetPosition()==POS_FACEUP_ATTACK
	end
	--Hope
	function DestinyDraw.DDPfiler(c,qt,tp)
		return Duel.GetMatchingGroupCount(Card.IsCode,tp,0x13+LOCATION_REMOVED,0,nil,c:GetCode())<qt
	end
	function DestinyDraw.DDCfiler(c)
		return c:IsSetCard(0x7f) and c:IsSetCard(0x1048)
	end
	--Syncho
	function DestinyDraw.RDSfiler(c)
		return c:IsCode(44508094) or c:IsCode(70902743) 
	end
	function DestinyDraw.RDSfiler2(c,tp)
		return c:IsCode(44508094) 
			and Duel.IsExistingMatchingCard(DestinyDraw.RDSfiler21,tp,LOCATION_MZONE,0,1,nil,c:GetLevel())
	end
	function DestinyDraw.RDSfiler21(c,lv)
		return c:IsType(TYPE_TUNER) and c:IsType(TYPE_SYNCHRO) and (c:GetLevel()+lv)==10
	end
	function DestinyDraw.RDSSfiler1(c,tp,code)
		return c:IsCode(code) 
			and Duel.IsExistingMatchingCard(DestinyDraw.RDSSfiler2,tp,LOCATION_MZONE,0,1,nil,c:GetLevel(),tp)
	end
	function DestinyDraw.RDSSfiler2(c,lv,tp)
		return c:IsCode(21159309)
			and Duel.IsExistingMatchingCard(DestinyDraw.RDSSfiler3,tp,LOCATION_MZONE,0,1,nil,c:GetLevel()+lv)
	end
	function DestinyDraw.RDSSfiler3(c,lv)
		return (c:GetLevel()+lv)==10 and not c:IsType(TYPE_TUNER)
	end
	function DestinyDraw.RDDSfiler(c,tp)
		return c:IsCode(70902743) 
			and Duel.IsExistingMatchingCard(DestinyDraw.RDDSfiler21,tp,LOCATION_MZONE,0,1,nil,c:GetLevel(),tp)
	end
	function DestinyDraw.RDDSfiler21(c,lv,tp)
		return c:IsType(TYPE_TUNER) 
			and Duel.IsExistingMatchingCard(DestinyDraw.RRDDSfiler22,tp,LOCATION_MZONE,0,1,nil,c:GetLevel()+lv)
	end
	function DestinyDraw.RRDDSfiler22(c,lv)
		return c:IsType(TYPE_TUNER) and (c:GetLevel()+lv)==12
	end
	function DestinyDraw.RRDSSfiler1(c,tp)
		return c:IsCode(2403771) 
			and Duel.IsExistingMatchingCard(DestinyDraw.RRDSSfiler2,tp,LOCATION_MZONE,0,1,nil,c:GetLevel())
	end
	function DestinyDraw.RRDSSfiler2(c,lv)
		return c:IsType(TYPE_TUNER) and (c:GetLevel()+lv)==8
	end
	function DestinyDraw.RRDSfiler(c)
		return c:IsCode(2403771) 
	end
	function DestinyDraw.RRDSfiler2(c,qt)
		return c:IsType(TYPE_TUNER) and c:GetLevel()==qt
	end
	function DestinyDraw.sfiler2(c,tp)
		return c:IsType(TYPE_TUNER) and c:IsType(TYPE_SYNCHRO)
			and Duel.IsExistingMatchingCard(DestinyDraw.sfiler22,tp,LOCATION_MZONE,0,2,c,c:GetLevel())
	end
	function DestinyDraw.sfiler22(c,lv)
		return not c:IsType(TYPE_TUNER) and c:IsType(TYPE_SYNCHRO) and (c:GetLevel()+lv)==12
	end

	function DestinyDraw.ASTRUM(c,tp)
		local rk=c:GetRank()
		return rk>0 and c:IsFaceup() and Duel.IsExistingMatchingCard(DestinyDraw.ASTRUM2,tp,LOCATION_EXTRA,0,1,nil,rk+1,tp,c:GetCode())
			and not Duel.IsExistingMatchingCard(DestinyDraw.ASTRUM3,tp,LOCATION_MZONE,0,1,nil,rk)
	end
	function DestinyDraw.ASTRUM1(c,tp)
		local rk=c:GetRank()
		return rk>0 and Duel.IsExistingMatchingCard(DestinyDraw.ASTRUM2,tp,LOCATION_EXTRA,0,1,nil,rk+1,tp,c:GetCode())
	end
	function DestinyDraw.ASTRUM2(c,rk,tp,code)
		if c:GetOriginalCode()==6165656 and code~=48995978 then return false end
		return (c:GetRank()==rk or c:GetRank()==rk+1) 
	end
	function DestinyDraw.ASTRUM3(c,rk)
		return c:IsFaceup() and c:GetRank()>rk
	end
	function DestinyDraw.barfiler(c,code)
		return c:IsCode(code) 
	end

	function DestinyDraw.drcon(e,tp,eg,ep,ev,re,r,rp)
		return Duel.GetFlagEffect(tp,99999980)~=0 and Duel.GetTurnCount()~=1
			and DestinyDraw[tp] and DestinyDraw[tp]:FilterCount(Card.IsLocation,nil,LOCATION_DECK)>0
			and ( (Duel.GetLP(tp)<Duel.GetLP(1-tp) and Duel.GetLP(tp)<2500) or ((Duel.GetLP(1-tp)-Duel.GetLP(tp))>=4000))
			and Duel.GetMatchingGroupCount(nil,tp,LOCATION_DECK,0,nil)>0			
	end
	function DestinyDraw.drop(e,tp,eg,ep,ev,re,r,rp)
		aux.KDraw(tp,1)
	end
	finishsetup()
end

function aux.KDraw(ttp,count)
	local e=Effect.GlobalEffect()
	if Duel.GetTurnCount()~=1 and Duel.GetMatchingGroupCount(nil,ttp,LOCATION_DECK,0,nil)>0 
 
		and (Duel.GetFlagEffect(ttp,99999980)~=0
			 and DestinyDraw[ttp] and DestinyDraw[ttp]:FilterCount(Card.IsLocation,nil,LOCATION_DECK)>0
			 and ( (Duel.GetLP(ttp)<Duel.GetLP(1-ttp) and Duel.GetLP(ttp)<2500) or ((Duel.GetLP(1-ttp)-Duel.GetLP(ttp))>=4000)))
 
		and ( (Duel.GetFlagEffect(ttp,90999980)~=0 and Duel.GetFlagEffect(ttp,90999980)<2)
		
		  or  (Duel.GetFlagEffect(ttp,92999980)~=0 and (Duel.GetLP(1-ttp)-Duel.GetLP(ttp))>=4000)
		  
		  or (Duel.GetFlagEffect(ttp,93999980)~=0 and Duel.GetLP(1-ttp)>=Duel.GetLP(ttp) and Duel.GetFlagEffect(ttp,99999960)==0 and (Duel.GetMatchingGroupCount(c157.RDSfiler,ttp,LOCATION_MZONE,0,nil)>0 or (Duel.GetMatchingGroupCount(c157.RRDSfiler,ttp,LOCATION_MZONE,0,nil)>0 and Duel.GetMatchingGroupCount(c157.RRDSfiler2,ttp,LOCATION_MZONE,0,nil,1)>0))) 
		  
		  or (Duel.GetFlagEffect(ttp,90799980)~=0 and Duel.GetLP(ttp)<=4000 and Duel.GetFieldGroupCount(ttp,LOCATION_HAND,0)<3)
		  
		  or Duel.GetFlagEffect(ttp,388)~=0 
		  
		  or (Duel.GetLP(ttp)<=2000 and Duel.GetFlagEffect(ttp,91999980)>0 and Duel.GetFlagEffect(ttp,91999980)<4)
		  
		  or (Duel.GetFlagEffect(ttp,703)~=0 and ( (Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,16195942)>0 and Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_DECK,0,nil,0x95)>0)
		  or (Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,42160203)>0 and Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_DECK,0,nil,0x95)>0) or (Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,90036274)>0 and Duel.GetMatchingGroupCount(Card.IsType,ttp,LOCATION_DECK,0,nil,TYPE_TUNER)>0) or (Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,82044279)>0 and Duel.GetMatchingGroupCount(Card.IsType,ttp,LOCATION_DECK,0,nil,TYPE_TUNER)>0) or (Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,70771599)>0 and Duel.GetMatchingGroupCount(Card.IsType,ttp,LOCATION_DECK,0,nil,TYPE_TUNER)>0) or (Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,41209827)>0 and Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_DECK,0,nil,0x46)>0) or (Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,511009415)>0 and Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_DECK,0,nil,0x46)>0) or (Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,43387895)>0 and Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_DECK,0,nil,0x46)>0) ) ) ) then

			 for i=1,count do
				 local g=DestinyDraw[ttp]:Filter(Card.IsLocation,nil,LOCATION_DECK)
				 if #g>0 and Duel.SelectYesNo(ttp,aux.Stringid(13709,11)) then
					 DestinyDraw[ttp]:DeleteGroup()
					 DestinyDraw[ttp]=nil
					 Duel.Hint(HINT_CARD,0,85)
					 local tc=g:RandomSelect(ttp,1):GetFirst()
					 Duel.MoveSequence(tc,0)
					 Duel.Hint(HINT_MESSAGE,1-ttp,aux.Stringid(13709,11))
				 end

				 if Duel.GetFlagEffect(ttp,90999980)~=0 and Duel.SelectYesNo(ttp,aux.Stringid(123106,8)) then
					 local op=0					
					 if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND+LOCATION_ONFIELD+LOCATION_GRAVE+LOCATION_REMOVED,0,nil,57734012)<4 and Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_HAND,0,nil,57734012)==0 then
						 op=Duel.SelectOption(ttp,aux.Stringid(13717,1),aux.Stringid(123106,8)) 
					 end
					 if op==0 then 
						Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
						local destinytc=Duel.SelectMatchingCard(ttp,nil,ttp,LOCATION_DECK,0,1,1,nil):GetFirst()
						Duel.MoveSequence(destinytc,0) 
					 end
					 if op==1 then 
						if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK,0,nil,57734012)==0 then
							local token=Duel.CreateToken(ttp,11370100,nil,nil,nil,nil,nil,nil)
							Duel.DisableShuffleCheck()	
							Duel.SendtoDeck(token,ttp,0,REASON_RULE)
						else 
							local destinytc=Duel.GetFirstMatchingCard(Card.IsCode,ttp,LOCATION_DECK,0,nil,57734012)
							Duel.MoveSequence(destinytc,0) 
						end 
					end	
				end

				if Duel.GetFlagEffect(ttp,89999998)~=0 then Duel.Hint(HINT_CARD,0,510000102) end	
					Duel.Hint(HINT_MESSAGE,1-ttp,aux.Stringid(123106,8))
					Duel.RegisterFlagEffect(ttp,99999960,0,0,1) 
				end
	 
				if Duel.GetFlagEffect(ttp,91999980)~=0 and Duel.SelectYesNo(ttp,aux.Stringid(111011901,1)) then
					if Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_REMOVED+LOCATION_MZONE,0,nil,0x7f)>0
					or Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,93717133)>0 then
						op=Duel.SelectOption(ttp,aux.Stringid(13717,1),aux.Stringid(13717,2)) 
					end
					if op==0 then 
						Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_TARGET)
						local destinytc=Duel.SelectMatchingCard(ttp,nil,ttp,LOCATION_DECK,0,1,1,nil):GetFirst()
						Duel.MoveSequence(destinytc,0) 
					end
					if op==1 then 			
						local ZWP=Group.CreateGroup()
						if Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_MZONE,0,nil,0x7f)>0 then
							local pd1=Duel.CreateToken(ttp,266,nil,nil,nil,nil,nil,nil)
							if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND+LOCATION_ONFIELD+LOCATION_GRAVE+LOCATION_REMOVED,0,nil,81471108)<1 then
								ZWP:AddCard(pd1) 
							end
							local pd2=Duel.CreateToken(ttp,264,nil,nil,nil,nil,nil,nil)
							if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND+LOCATION_ONFIELD+LOCATION_GRAVE+LOCATION_REMOVED,0,nil,45082499)<1 then
								ZWP:AddCard(pd2) 
							end
							local pd3=Duel.CreateToken(ttp,262,nil,nil,nil,nil,nil,nil)
							if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND+LOCATION_ONFIELD+LOCATION_GRAVE+LOCATION_REMOVED,0,nil,2648201)<1 and Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,56840427)<1 then
								ZWP:AddCard(pd3) 
							end
							local pd4=Duel.CreateToken(ttp,40941889,nil,nil,nil,nil,nil,nil)
							if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND+LOCATION_ONFIELD+LOCATION_GRAVE+LOCATION_REMOVED,0,nil,40941889)<1 then
								ZWP:AddCard(pd4) 
							end
							local pd14=Duel.CreateToken(ttp,261,nil,nil,nil,nil,nil,nil)
							if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND+LOCATION_ONFIELD+LOCATION_GRAVE+LOCATION_REMOVED,0,nil,261)<1 then
								ZWP:AddCard(pd14) 
							end
						end		
						if Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_MZONE,0,nil,0x7f)>0
							and Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_GRAVE,0,nil,0x7e)>0 then
							local pd5=Duel.CreateToken(ttp,12927849,nil,nil,nil,nil,nil,nil)
							if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND+LOCATION_ONFIELD+LOCATION_GRAVE+LOCATION_REMOVED,0,nil,12927849)<1 then
								ZWP:AddCard(pd5) 
							end
						end
						if Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_REMOVED,0,nil,0x7f)>0 then
							local pd6=Duel.CreateToken(ttp,263,nil,nil,nil,nil,nil,nil)
							if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND+LOCATION_ONFIELD+LOCATION_GRAVE+LOCATION_REMOVED,0,nil,18865703)<1 then
								ZWP:AddCard(pd6) 
							end
						end
						if Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_MZONE,0,nil,0x7f)>0
							and (Duel.GetLP(1-ttp)-Duel.GetLP(ttp))>=2000 then
							local pd7=Duel.CreateToken(ttp,29353756,nil,nil,nil,nil,nil,nil) 
							if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND+LOCATION_ONFIELD+LOCATION_GRAVE+LOCATION_REMOVED,0,nil,29353756)<1 then
								ZWP:AddCard(pd7) 
							end
						end
						if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,56840427)>0 then
							local pd8=Duel.CreateToken(ttp,76080032,nil,nil,nil,nil,nil,nil)
							if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND+LOCATION_ONFIELD+LOCATION_GRAVE+LOCATION_REMOVED,0,nil,76080032)<1 then
								ZWP:AddCard(pd8) 
							end
							local pd9=Duel.CreateToken(ttp,267,nil,nil,nil,nil,nil,nil)  
							if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND+LOCATION_ONFIELD+LOCATION_GRAVE+LOCATION_REMOVED,0,nil,87008374)<1 then
								ZWP:AddCard(pd9) 
							end
						end
						if Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_MZONE,0,nil,0x7f)>0 
							and Duel.GetMatchingGroupCount(c157.rankfiler,1-ttp,0,LOCATION_MZONE,nil)>0  then
							local pd10=Duel.CreateToken(ttp,452,nil,nil,nil,nil,nil,nil) 
							if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND+LOCATION_ONFIELD+LOCATION_GRAVE+LOCATION_REMOVED,0,nil,71345905)<1 then
								ZWP:AddCard(pd10) 
							end
						end 
						if Duel.GetMatchingGroupCount(c157.DDCfiler,ttp,LOCATION_MZONE,0,nil)>0 then
							local pd12=Duel.CreateToken(ttp,258,nil,nil,nil,nil,nil,nil)
							if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND+LOCATION_ONFIELD+LOCATION_GRAVE+LOCATION_REMOVED,0,nil,6330307)<1 then
								ZWP:AddCard(pd12)   
							end
						end   
						if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,93717133)>0 then
							local pd13=Duel.CreateToken(ttp,51865604,nil,nil,nil,nil,nil,nil)
							if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND+LOCATION_ONFIELD+LOCATION_GRAVE+LOCATION_REMOVED,0,nil,51865604)<1 then
								ZWP:AddCard(pd13)   
							end
						end   
						if Duel.GetMatchingGroupCount(c157.hopefilter,ttp,LOCATION_MZONE,0,nil)>0 and Duel.IsExistingTarget(c157.zspfilter,ttp,LOCATION_GRAVE,0,1,nil,e,ttp) then
							local pd16=Duel.CreateToken(ttp,438,nil,nil,nil,nil,nil,nil)
							if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND+LOCATION_ONFIELD+LOCATION_GRAVE+LOCATION_REMOVED,0,nil,438)<1 then
								ZWP:AddCard(pd16)   
							end
						end   
						if Duel.IsExistingMatchingCard(c157.filterno,ttp,LOCATION_GRAVE,0,2,nil,e,ttp) then
							local pd17=Duel.CreateToken(ttp,366,nil,nil,nil,nil,nil,nil)
							if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK+LOCATION_HAND+LOCATION_ONFIELD+LOCATION_GRAVE+LOCATION_REMOVED,0,nil,366)<1 then
								ZWP:AddCard(pd17)   
							end
						end   	 
						local dtz=ZWP:Filter(c157.DDPfiler,nil,1,ttp)
						if not dtz then
							dtz=ZWP:Filter(c157.DDPfiler,nil,3,ttp)
						end
						local bpd=Duel.GetMatchingGroupCount(nil,ttp,LOCATION_DECK,0,nil)
						local btc=0
						local dtzc=dtz:GetCount()
						if dtzc==0 then dtzc=1 end
						if bpd>0 then btc=bpd%(dtzc) end
						local ttc=dtz:GetFirst()
						if dtz:GetCount()>0 then
							while btc>0 do 
								ttc=dtz:GetNext()
								btc=btc-1
							end   
						end
						local token=Duel.CreateToken(ttp,ttc:GetOriginalCode(),nil,nil,nil,nil,nil,nil)
						Duel.DisableShuffleCheck() 
						Duel.SendtoDeck(token,ttp,0,REASON_RULE)	 
					end		 
					if Duel.GetFlagEffect(ttp,89999997)~=0 and Duel.GetFlagEffect(ttp,91999980)==1 then Duel.Hint(HINT_CARD,0,510000103) end
					if Duel.GetFlagEffect(ttp,89999997)~=0 and Duel.GetFlagEffect(ttp,91999980)==2 then Duel.Hint(HINT_CARD,0,510000104) end   
					if Duel.GetFlagEffect(ttp,89999997)~=0 and Duel.GetFlagEffect(ttp,91999980)==3 then 
						Duel.Hint(HINT_CARD,0,510000105) 
					end   
					Duel.Hint(HINT_MESSAGE,1-ttp,aux.Stringid(111011901,2))
					Duel.RegisterFlagEffect(ttp,99999960,0,0,1)
					Duel.RegisterFlagEffect(ttp,91999980,0,0,1)
				end
	 
				if Duel.GetFlagEffect(ttp,92999980)~=0 and Duel.GetMatchingGroupCount(Card.IsType,ttp,LOCATION_DECK,0,nil,TYPE_SPELL)>0
					and Duel.SelectYesNo(ttp,aux.Stringid(123106,7)) then
					local g=Duel.GetMatchingGroup(Card.IsType,ttp,LOCATION_DECK,0,nil,TYPE_SPELL)
					local g2=g:RandomSelect(ttp,1)
					Duel.MoveSequence(g2:GetFirst(),0)
					if Duel.GetFlagEffect(ttp,89999995)~=0 then 
						Duel.Hint(HINT_CARD,0,510000106) 
					end  
					Duel.Hint(HINT_MESSAGE,1-ttp,aux.Stringid(123106,7))
				end
	 
				if Duel.GetFlagEffect(ttp,93999980)~=0 then
					if Duel.GetMatchingGroupCount(c157.RDSfiler,ttp,LOCATION_MZONE,0,nil)>0
						and Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_ONFIELD+LOCATION_GRAVE+LOCATION_HAND+LOCATION_REMOVED,0,nil,21159309)<3 
						and Duel.SelectYesNo(ttp,aux.Stringid(13709,12)) then
						if Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_DECK,0,nil,21159309)==0 then
							local token=Duel.CreateToken(ttp,21159309,nil,nil,nil,nil,nil,nil)  
							Duel.DisableShuffleCheck() 
							Duel.SendtoDeck(token,ttp,0,REASON_RULE)
						else
							local destinytc=Duel.GetFirstMatchingCard(Card.IsCode,ttp,LOCATION_DECK,0,nil,7841112)
							Duel.MoveSequence(destinytc,0)
						end   
						if Duel.GetFlagEffect(ttp,89999996)~=0 then Duel.Hint(HINT_CARD,0,510000107) 
						end  
						Duel.Hint(HINT_MESSAGE,1-ttp,aux.Stringid(13709,15))
						Duel.RegisterFlagEffect(ttp,93999960,0,0,1)
						Duel.RegisterFlagEffect(ttp,99999960,0,0,1)
					end
				end
	 
				if Duel.GetFlagEffect(ttp,90799980)~=0 and Duel.SelectYesNo(ttp,aux.Stringid(784,2)) then
					Duel.Hint(HINT_SELECTMSG,ttp,0)
					local code=Duel.AnnounceCard(ttp,TYPE_FUSION+TYPE_SYNCHRO+TYPE_XYZ+TYPE_LINK,OPCODE_ISTYPE,OPCODE_NOT)
					local tg=Duel.GetFirstMatchingCard(Card.IsCode,ttp,LOCATION_DECK,0,nil,code)
					if tg then
						Duel.MoveSequence(tg,0)
					else local token=Duel.CreateToken(ttp,code)
						Duel.SendtoDeck(token,ttp,0,REASON_RULE)
					end
					if Duel.GetFlagEffect(ttp,89999993)~=0 then Duel.Hint(HINT_CARD,0,510000108) end  
					Duel.Hint(HINT_MESSAGE,1-ttp,aux.Stringid(784,2))
					--Duel.RegisterFlagEffect(ttp,99999960,0,0,1)
				end   
 
				if Duel.GetFlagEffect(ttp,388)~=0 
					and Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_DECK,0,nil,0x95)>0 and Duel.SelectYesNo(ttp,aux.Stringid(13713,8)) then
					Duel.Hint(HINT_SELECTMSG,ttp,HINTMSG_TARGET)
					local destinytc=Duel.SelectMatchingCard(ttp,Card.IsSetCard,ttp,LOCATION_DECK,0,1,1,nil,0x95):GetFirst()
					Duel.MoveSequence(destinytc,0) 
					Duel.Hint(HINT_MESSAGE,1-ttp,aux.Stringid(13713,8))
				end
 
				if Duel.GetFlagEffect(ttp,703)~=0 and Duel.SelectYesNo(ttp,aux.Stringid(13712,0)) then
					local off=1
					local ops={}
					local opval={}
					if (Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,16195942)>0 or Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,42160203)>0) and Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_DECK,0,nil,0x95)>0 then
						ops[off]=aux.Stringid(13712,1)
						opval[off-1]=1
						off=off+1
					end
					if (Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,90036274)>0 or Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,82044279)>0 or Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,70771599)>0) and Duel.GetMatchingGroupCount(Card.IsType,ttp,LOCATION_DECK,0,nil,TYPE_TUNER)>0 then
						ops[off]=aux.Stringid(13712,2)
						opval[off-1]=2
						off=off+1
					end
					if (Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,41209827)>0 or Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,511009415)>0 or Duel.GetMatchingGroupCount(Card.IsCode,ttp,LOCATION_MZONE,0,nil,43387895)>0) and Duel.GetMatchingGroupCount(Card.IsSetCard,ttp,LOCATION_DECK,0,nil,0x46)>0 then
						ops[off]=aux.Stringid(13712,3)
						opval[off-1]=3
						off=off+1
					end
					local op=Duel.SelectOption(ttp,table.unpack(ops))   
					if opval[op]==1 then 
						Duel.Hint(HINT_SELECTMSG,ttp,HINTMSG_TARGET)
						local destinytc=Duel.SelectMatchingCard(ttp,Card.IsSetCard,ttp,LOCATION_DECK,0,1,1,nil,0x95):GetFirst()
						Duel.MoveSequence(destinytc,0) 
						Duel.Hint(HINT_MESSAGE,1-ttp,aux.Stringid(13712,0))
					end
					if opval[op]==2 then 
						Duel.Hint(HINT_SELECTMSG,ttp,HINTMSG_TARGET)
						local destinytc=Duel.SelectMatchingCard(ttp,Card.IsType,ttp,LOCATION_DECK,0,1,1,nil,TYPE_TUNER):GetFirst()
						Duel.MoveSequence(destinytc,0) 
						Duel.Hint(HINT_MESSAGE,1-ttp,aux.Stringid(13712,0))
					end
					if opval[op]==3 then 
						Duel.Hint(HINT_SELECTMSG,ttp,HINTMSG_TARGET)
						local destinytc=Duel.SelectMatchingCard(ttp,Card.IsSetCard,ttp,LOCATION_DECK,0,1,1,nil,0x46):GetFirst()
						Duel.MoveSequence(destinytc,0) 
						Duel.Hint(HINT_MESSAGE,1-ttp,aux.Stringid(13712,0))
					end
				end
			end 
		end
	end
end

local draw=Duel.Draw
function Duel.Draw(ttp,count,reason)
    aux.KDraw(ttp,count,reason)
	return draw(ttp,count,reason)
end

local exist=Duel.IsExistingMatchingCard
function Duel.IsExistingMatchingCard(f,tp,s,o,count,ex,...)
   if tp==nil then tp=0 end
   if f==nil then f=aux.TRUE end     
   local nf=f
   if Duel.GetFlagEffect(tp,782)~=0 then s=bit.exclude(s,LOCATION_MZONE) s=bit.exclude(s,LOCATION_SZONE) s=bit.exclude(s,LOCATION_GRAVE) s=bit.exclude(s,LOCATION_HAND) end
   if Duel.GetFlagEffect(1-tp,782)~=0 then o=bit.exclude(o,LOCATION_MZONE) o=bit.exclude(o,LOCATION_SZONE) o=bit.exclude(o,LOCATION_GRAVE) o=bit.exclude(o,LOCATION_HAND) end

   if tp==0 and bit.band(s,LOCATION_EXTRA)~=0 then return true end
   return exist(nf,tp,s,o,count,ex, ...)
end
local selectc=Duel.SelectMatchingCard
function Duel.SelectMatchingCard(sel_player,f,tp,s,o,mint,maxt,ex, ...)
   if tp==nil then tp=0 end
   if f==nil then f=aux.TRUE end    
   local nf=f
   if Duel.IsPlayerAffectedByEffect(tp,810)~=nil then
     if bit.band(s,LOCATION_SZONE)~=0 and bit.band(s,LOCATION_MZONE)==0 then s=s+LOCATION_MZONE nf=function(c,...) return (f==nil or f(c,...)) and (not c:IsLocation(LOCATION_MZONE) or (c:IsLocation(LOCATION_MZONE) and c:GetFlagEffect(810)~=0)) end end
     if bit.band(s,LOCATION_MZONE)~=0 and bit.band(s,LOCATION_SZONE)==0 then nf=function(c,...) return (f==nil or f(c,...)) and (c:IsLocation(LOCATION_MZONE) and c:GetFlagEffect(810)==0) end end
   end
   if Duel.IsPlayerAffectedByEffect(1-tp,810)~=nil then
     if bit.band(o,LOCATION_SZONE)~=0 and bit.band(o,LOCATION_MZONE)==0 then o=o+LOCATION_MZONE nf=function(c,...) return (f==nil or f(c,...)) and (not c:IsLocation(LOCATION_MZONE) or (c:IsLocation(LOCATION_MZONE) and c:GetFlagEffect(810)~=0)) end end
     if bit.band(o,LOCATION_MZONE)~=0 and bit.band(o,LOCATION_SZONE)==0 then nf=function(c,...) return (f==nil or f(c,...)) and (c:IsLocation(LOCATION_MZONE) and c:GetFlagEffect(810)==0) end end
   end
 
   if Duel.GetFlagEffect(tp,782)~=0 then s=bit.exclude(s,LOCATION_MZONE) s=bit.exclude(s,LOCATION_SZONE) s=bit.exclude(s,LOCATION_GRAVE) s=bit.exclude(s,LOCATION_HAND) end
   if Duel.GetFlagEffect(1-tp,782)~=0 then o=bit.exclude(o,LOCATION_MZONE) o=bit.exclude(o,LOCATION_SZONE) o=bit.exclude(o,LOCATION_GRAVE) o=bit.exclude(o,LOCATION_HAND) end
 
   if sel_player==0 and bit.band(s,LOCATION_EXTRA)~=0 and aux.Stringid(826,12) then 
	   local code=Duel.AnnounceCard(sel_player,TYPE_FUSION+TYPE_SYNCHRO+TYPE_XYZ+TYPE_LINK,OPCODE_ISTYPE)
	   local token=Duel.CreateToken(sel_player,code)
	   if nf(token,...) then
		  Duel.SendtoDeck(token,sel_player,0,REASON_RULE)
		  if maxt==1 then return Group.FromCards(token) end
		  return selectc(sel_player,nf,tp,s,o,mint-1,maxt-1,ex, ...):Merge(Group.FromCards(token))
	   end
   end  
   return selectc(sel_player,nf,tp,s,o,mint,maxt,ex, ...)
end