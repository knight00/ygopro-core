local s,id=GetID()
if s then
	function s.initial_effect(c)
	end
end
if not id then id=86 end
if not KField then
	KField={}
	local function finishsetup()
		local e1=Effect.GlobalEffect()
		e1:SetType(EFFECT_TYPE_FIELD+EFFECT_TYPE_CONTINUOUS)
		e1:SetCode(EVENT_STARTUP)
		e1:SetOperation(KField.op)
		Duel.RegisterEffect(e1,0)
    end

	function KField.op(e,tp,eg,ep,ev,re,r,rp)  
		local c=e:GetHandler()
		local tk1=0 local tk2=0		
        if Duel.SelectYesNo(tp,aux.Stringid(13710,1)) then tk1=1 end
		if Duel.SelectYesNo(1-tp,aux.Stringid(13710,1)) then tk2=1 end
		if tk1>0 or tk2>0 then
		local ttp=tp
		if tk1~=1 then ttp=1-tp end
		while ttp do
			local tk=Duel.AnnounceCardFilter(ttp,TYPE_FIELD,OPCODE_ISTYPE)

			if tk~=0 then
				local token=Duel.CreateToken(ttp,tk,nil,nil,nil,nil,nil,nil)   
				Duel.SpecialSummonStep(token,0,ttp,ttp,false,false,POS_FACEUP)
				local e1=Effect.CreateEffect(c)
				e1:SetCode(EFFECT_CHANGE_TYPE)
				e1:SetType(EFFECT_TYPE_SINGLE)
				e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
				e1:SetValue(TYPE_SPELL+TYPE_FIELD)
				token:RegisterEffect(e1,true)
				local te,eg,ep,ev,re,r,rp=token:CheckActivateEffect(true,true,true)
				local tep=token:GetControler()
				local condition=te:GetCondition()
				local cost=te:GetCost()
				Duel.ClearTargetCard()
				local target=te:GetTarget()
				local operation=te:GetOperation()
				if not Duel.MoveToField(token,ttp,ttp,LOCATION_SZONE,POS_FACEUP,true) then return end
				Duel.Hint(HINT_CARD,0,token:GetOriginalCode())
				token:CreateEffectRelation(te)
				if cost then cost(e,tep,eg,ep,ev,re,r,rp,1) end
				if target then target(e,tep,eg,ep,ev,re,r,rp,1) end
				local gg=Duel.GetChainInfo(0,CHAININFO_TARGET_CARDS)
				if gg then
					local etc=gg:GetFirst()
					while etc do
						etc:CreateEffectRelation(te)
						etc=gg:GetNext()
					end
				end
				Duel.BreakEffect()
				if operation then operation(te,tep,eg,ep,ev,re,r,rp) end
				token:ReleaseEffectRelation(te)
				if etc then 
					etc=gg:GetFirst()
					while etc do
						etc:ReleaseEffectRelation(te)
						etc=gg:GetNext()
					end
				end 
				Duel.SpecialSummonComplete() 
			end
			
			if ttp==tp and tk2==1 then 
				ttp=1-tp
			else 
				ttp=nil 
			end 
		end	   
	end      
	finishsetup()
 end   